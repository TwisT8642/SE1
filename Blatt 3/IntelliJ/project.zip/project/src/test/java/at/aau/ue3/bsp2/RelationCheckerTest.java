package at.aau.ue3.bsp2;

public class RelationCheckerTest {
    //TODO fill tests
}
