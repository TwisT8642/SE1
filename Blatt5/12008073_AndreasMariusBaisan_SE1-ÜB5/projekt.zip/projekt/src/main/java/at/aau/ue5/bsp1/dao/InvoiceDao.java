package at.aau.ue5.bsp1.dao;

import at.aau.ue5.bsp1.entity.Invoice;

public interface InvoiceDao extends Dao<Long, Invoice> {

}
