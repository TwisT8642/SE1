//12008073_AndreasMariusBaisan
package at.aau.ue5.bsp3;

public enum Ide {
    ECLIPSE, INTELLIJ, NANO
}
