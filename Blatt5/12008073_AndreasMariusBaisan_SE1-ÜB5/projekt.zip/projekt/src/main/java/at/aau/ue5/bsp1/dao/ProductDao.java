package at.aau.ue5.bsp1.dao;

import at.aau.ue5.bsp1.entity.Product;

public interface ProductDao extends Dao<Long, Product> {
}
