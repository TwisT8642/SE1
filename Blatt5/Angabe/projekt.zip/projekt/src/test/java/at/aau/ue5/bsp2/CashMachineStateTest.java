package at.aau.ue5.bsp2;

import org.junit.jupiter.api.Test;

public class CashMachineStateTest {

    @Test
    public void test(){}

}
