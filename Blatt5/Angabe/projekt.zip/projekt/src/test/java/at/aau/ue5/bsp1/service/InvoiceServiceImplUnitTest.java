package at.aau.ue5.bsp1.service;

import org.junit.jupiter.api.Test;

public class InvoiceServiceImplUnitTest {
    @Test
    public void test(){}
}
