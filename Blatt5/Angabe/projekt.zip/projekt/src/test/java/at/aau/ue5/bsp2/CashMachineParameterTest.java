package at.aau.ue5.bsp2;

import org.junit.jupiter.api.Test;

public class CashMachineParameterTest {
    @Test
    public void test(){}
}
