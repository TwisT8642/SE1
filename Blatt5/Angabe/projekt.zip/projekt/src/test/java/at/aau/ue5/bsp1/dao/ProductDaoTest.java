package at.aau.ue5.bsp1.dao;

import org.junit.jupiter.api.Test;

public class ProductDaoTest {
    @Test
    public void test(){}
}
