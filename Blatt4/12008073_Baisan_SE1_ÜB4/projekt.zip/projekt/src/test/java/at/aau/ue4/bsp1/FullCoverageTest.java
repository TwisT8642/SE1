package at.aau.ue4.bsp1;


import org.junit.jupiter.api.Test;

public class FullCoverageTest {
    @Test
    public void test(){}
}
