package at.aau.ue4.bsp3;

import org.junit.jupiter.api.Test;

public class McCabeTest {
    @Test
    public void test() {}
}
